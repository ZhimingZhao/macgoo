const current= document.querySelector('#current');
const imgs=document.querySelectorAll('.imgs img');

img.forEach(img => img.addEventListener('click',()=>current.src=e.target.src));